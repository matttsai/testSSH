package com.test.cyt.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.view.View.OnClickListener;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class List2Activity extends AppCompatActivity {
    private Button button_add, button_del;
    private ListView listView2;
    private ArrayAdapter<String> aa;
    private List<String> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list2);
        buildViews();
    }

    public void buildViews(){
        button_add = (Button) findViewById(R.id.button_add);
        button_del = (Button) findViewById(R.id.button_del);
        listView2 = (ListView) findViewById(R.id.listView_2);

        button_add.setOnClickListener(button_add_listener);
        button_del.setOnClickListener(button_del_listener);


        data = new ArrayList<>();

        for (int i = 0; i< 5; i++){
            data.add("Item" + i);
        }
        aa = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data);
        listView2.setAdapter(aa);;
    }

    private OnClickListener button_add_listener = new OnClickListener(){
        public void onClick(View v){
            data.add("new added Item" + data.size());
            aa.notifyDataSetChanged();
        }
    };
    private OnClickListener button_del_listener = new OnClickListener(){
        public void onClick(View v){
            if(data.size() > 0){
                data.remove(data.size()-1);
                aa.notifyDataSetChanged();
            }
        }
    };

}
