package com.test.cyt.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;
import android.widget.Toast;


public class ListActivity extends AppCompatActivity {
    private Button button_back;
    private ListView lvEdu;
    String msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        buildView();
    }
    private void buildView(){
        button_back = (Button) findViewById(R.id.button_back_from_list);
        button_back.setOnClickListener(button_back_listener);

        lvEdu = (ListView) findViewById(R.id.listViewEdu);
        ArrayAdapter<CharSequence> adEduList = ArrayAdapter.createFromResource(this,R.array.lvEduList,android.R.layout.simple_list_item_1);
        lvEdu.setAdapter(adEduList);
        lvEdu.setOnItemClickListener(lvListener);

    }
    private OnClickListener button_back_listener = new OnClickListener(){
        public void onClick(View v){
            button_back.setText("go back ......");
            finish();
        }
    };

    private OnItemClickListener lvListener = new OnItemClickListener() {
        public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
            msg = ((TextView)view).getText().toString();
            msg += position;
            Toast.makeText(ListActivity.this, msg, Toast.LENGTH_SHORT).show();
        }
    };
}
