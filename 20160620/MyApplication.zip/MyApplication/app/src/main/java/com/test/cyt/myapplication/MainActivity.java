package com.test.cyt.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    private Button button_list, button_list2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buildViews();
    }
    public void buildViews(){
        button_list = (Button) findViewById(R.id.button_list);
        button_list.setOnClickListener(this);
        button_list2 = (Button) findViewById(R.id.button_list2);
        button_list2.setOnClickListener(this);
    }
    public void onClick(View v){
        switch(v.getId()){
            case R.id.button_list:
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, ListActivity.class);
                startActivity(intent);
                break;
            case R.id.button_list2:
                Intent intent2 = new Intent();
                intent2.setClass(MainActivity.this, List2Activity.class);
                startActivity(intent2);
                break;
        }
    }
}
