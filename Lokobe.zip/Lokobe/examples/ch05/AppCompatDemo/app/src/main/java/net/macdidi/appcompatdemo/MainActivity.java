package net.macdidi.appcompatdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

// 目前的程式碼除了繼承自AppCompatActivity類別外
// 其它與一般傳統的Activity都一樣
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

}
