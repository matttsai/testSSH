package net.macdidi.myshoppinglist;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ListView function;
    private ShoppingDB myDb;

    private static final int SHOW_DOC = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        processViews();
        processControllers();

        myDb = ShoppingDB.getShoppingDB(getApplicationContext());

        if (TurtleUtil.isFirstTime(getApplicationContext())) {
            processFirstTime();
            TurtleUtil.setFirstTime(getApplicationContext());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        myDb.close();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SHOW_DOC) {
            Intent intent = new Intent();
            intent.setAction("net.macdidi.action.MAINTAIN_NAME_DATA");
            startActivity(intent);
        }
    }

    private void processViews() {
        function = (ListView) findViewById(R.id.function);

        ArrayAdapter<CharSequence> functionAdapter =
                ArrayAdapter.createFromResource(this,
                        R.array.function_array, android.R.layout.simple_list_item_1);
        function.setAdapter(functionAdapter);
    }

    private void processControllers() {
        function.setOnItemClickListener(new FunctionListener());
    }

    private class FunctionListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {
            Intent intent = new Intent();

            switch (position){
                case 0:
                    intent.setAction("net.macdidi.action.ADD_SHOPPING_DATA");
                    startActivity(intent);
                    break;
                case 1:
                    intent.setAction("net.macdidi.action.MAINTAIN_SHOPPING_DATA");
                    startActivity(intent);
                    break;
                case 2:
                    intent.setAction("net.macdidi.action.START_SHOPPING");
                    startActivity(intent);
                    break;
                case 3:
                    boolean showdocPref = TurtleUtil.isShowDoc(getApplicationContext());

                    if (showdocPref){
                        startActivityForResult(new Intent(MainActivity.this, NameMaintainDocActivity.class), SHOW_DOC);
                    }
                    else {
                        intent.setAction("net.macdidi.action.MAINTAIN_NAME_DATA");
                        startActivity(intent);
                    }

                    break;
                case 4:
                    AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                    adb.setTitle(getString(R.string.about));
                    adb.setIcon(R.drawable.about);
                    adb.setMessage(getString(R.string.about_message));
                    adb.setPositiveButton(getString(R.string.ok), null);
                    adb.show();

                    break;
            }

        }

    }

    private void processFirstTime() {
        AlertDialog.Builder adb = new AlertDialog.Builder(this);
        adb.setTitle(getString(R.string.first_time));
        adb.setMessage(getString(R.string.create_sample));

        adb.setPositiveButton(getString(R.string.ok),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        myDb.insert("Tooth brush", 2);
                        myDb.insert("Tooth paste", 1);
                        myDb.insert("Garbage bags", 2);

                        myDb.insertName("Tooth brush");
                        myDb.insertName("Tooth paste");
                        myDb.insertName("Garbage bags");
                    }
                });
        adb.setNegativeButton(getString(R.string.back), null);

        adb.show();
    }

}
