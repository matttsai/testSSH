package net.macdidi.myshoppinglist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class NameItemAdapter extends ArrayAdapter<NameItem> {

    private int resource;
    private List<NameItem> items;

    public NameItemAdapter(Context context, int resource,
            List<NameItem> items) {
        super(context, resource, items);
        this.resource = resource;
        this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout shoppingItemView;

        final NameItem item = getItem(position);

        String id = Long.toString(item.getId());
        String name = item.getName();
        boolean selected = item.isSelected();

        if (convertView == null) {
            shoppingItemView = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater vi = (LayoutInflater) getContext().getSystemService(
                    inflater);
            vi.inflate(resource, shoppingItemView, true);
        }
        else {
            shoppingItemView = (LinearLayout) convertView;
        }

        TextView idView = (TextView) shoppingItemView.findViewById(R.id.id);
        TextView nameView = (TextView) shoppingItemView.findViewById(R.id.name);
        CheckBox selectedView = (CheckBox) shoppingItemView.findViewById(R.id.selected);

        idView.setText(id);
        nameView.setText(name);
        selectedView.setChecked(selected);
        /*
        selectedView.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                    boolean isChecked) {
                item.setSelected(isChecked);
            }
        });
        */

        return shoppingItemView;
    }
    
    public void set(int index, NameItem item) {
        if (index >= 0 && index < items.size()) {
            items.set(index, item);
            notifyDataSetChanged();
        }
    }

}
