package net.macdidi.myshoppinglist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class NameMaintainActivity extends AppCompatActivity {
    
    private ListView name_items;
    private Button name_delete;
    private Button name_deselect_all;
    private Button name_select_all;
    
    private NameItemAdapter nia;
    
    private ShoppingDB myDb;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.name_maintain);
        
        myDb = ShoppingDB.getShoppingDB(getApplicationContext());
        
        processViews();
        processControllers();
        processModel();
        
        configFooter();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        saveStatus();
    }

    private void processViews() {
        name_items = (ListView) findViewById(R.id.name_items);
        name_delete = (Button) findViewById(R.id.name_delete);
        name_deselect_all = (Button) findViewById(R.id.name_deselect_all);
        name_select_all = (Button) findViewById(R.id.name_select_all);        
    }
    
    private void processControllers() {
        ButtonListener listener = new ButtonListener();
        
        name_delete.setOnClickListener(listener);
        name_deselect_all.setOnClickListener(listener);
        name_select_all.setOnClickListener(listener);
        
        name_items.setOnItemClickListener(new CheckedListener());
    }
    
    private class ButtonListener implements OnClickListener {

        @Override
        public void onClick(View view) {
            if (view == name_delete) {
                int selectedCount = getSelectedCount();
                
                if (selectedCount > 0) {
                    saveStatus();
                    
                    AlertDialog.Builder adb = new AlertDialog.Builder(NameMaintainActivity.this);
                    adb.setTitle(getString(R.string.delete_selected));
                    adb.setIcon(R.drawable.warning);
                    adb.setMessage(getString(R.string.confirm_delete_selected) + "\n\n" +
                            selectedCount + " " + getString(R.string.item));
                    
                    adb.setPositiveButton(getString(R.string.delete), 
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                myDb.deleteNameSelected();
                                processModel();
                                configFooter();
                            }
                        });
                    adb.setNegativeButton(getString(R.string.back), null);
                    
                    adb.show();
                }
            }
            else if (view == name_deselect_all) {
                for (int i = 0; i < nia.getCount(); i++) {
                    nia.getItem(i).setSelected(false);
                }
                
                myDb.updateAllNameUnselected();
                nia.notifyDataSetChanged();
                configFooter();
            }
            else if (view == name_select_all) {
                for (int i = 0; i < nia.getCount(); i++) {
                    nia.getItem(i).setSelected(true);
                }
                
                myDb.updateAllNameSelected();
                nia.notifyDataSetChanged();
                configFooter();
            }
        }
        
    }
    
    private class CheckedListener implements OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                long id) {            
            NameItem target = nia.getItem(position);
            target.setSelected(!target.isSelected());
            nia.set(position, target);
            configFooter();
        }
        
    }    
    
    private void processModel() {
        List<NameItem> all = myDb.getAllNameItem();
        nia = new NameItemAdapter(this, R.layout.namelist_view, all);
        name_items.setAdapter(nia);        
    }    
    
    private void saveStatus() {
        for (int i = 0; i < nia.getCount(); i++) {
            NameItem item = nia.getItem(i);
            myDb.updateNameSelected(item.getId(), item.isSelected());
        }        
    }
    
    private int getSelectedCount() {
        int result = 0;
        
        for (int i = 0; i < nia.getCount(); i++) {
            if (nia.getItem(i).isSelected()) {
                result++;
            }
        }
        
        return result;
    }
    
    private void configFooter() {
        int selectedCount = getSelectedCount();
        
        if (selectedCount > 0) {
            name_delete.setEnabled(true);
            name_delete.setText(getString(R.string.delete) + " (" + selectedCount + ")");
        }
        else {
            name_delete.setEnabled(false);
            name_delete.setText(getString(R.string.delete));
        }
    }    
    
}
