package net.macdidi.myshoppinglist;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

public class NameMaintainDocActivity extends AppCompatActivity {

    private static final int STEPS = 5;
    private int current = 0;
    private int[] docs;
    private int[] images; 
    
    private TextView doc;
    private ImageView image;
    private CheckBox disapear;
    private Button next;
    private Button previous;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.name_maintain_doc);
        
        processViews();
        processControllers();
        
        docs = new int[]{R.string.doc_step1, R.string.doc_step2,
                         R.string.doc_step3, R.string.doc_step4,
                         R.string.doc_step5};
        images = new int[]{R.drawable.demo01, R.drawable.demo02,
                           R.drawable.demo03, R.drawable.demo04,
                           R.drawable.demo05};
        configView();
    }
    
    private void processViews() {
        doc = (TextView) findViewById(R.id.doc);
        image = (ImageView) findViewById(R.id.image);
        disapear = (CheckBox) findViewById(R.id.disapear);
        previous = (Button) findViewById(R.id.previous);
        next = (Button) findViewById(R.id.next);
    }
    
    private void processControllers() {
        ButtonListener listener = new ButtonListener();
        previous.setOnClickListener(listener);
        next.setOnClickListener(listener);
    }
    
    private class ButtonListener implements OnClickListener {

        @Override
        public void onClick(View view) {
            if (view == previous) {
                if (current > 0) {
                    current--;
                }
            }
            else if (view == next) {
                if (current < (STEPS - 1)) {
                    current++;
                }
                else {
                    boolean showdocValue = !disapear.isChecked();
                    TurtleUtil.setShowDoc(getApplicationContext(), showdocValue);
                    
                    finish();
                }
            }
            
            configView();
        }
        
    }
    
    private void configView() {
        doc.setText(docs[current]);
        image.setImageResource(images[current]);        
        disapear.setVisibility(current == (STEPS - 1) ? View.VISIBLE : View.GONE);
        previous.setEnabled( current > 0 );
        next.setText( current == (STEPS - 1) ? R.string.ok : R.string.next);        
    }
    
}
