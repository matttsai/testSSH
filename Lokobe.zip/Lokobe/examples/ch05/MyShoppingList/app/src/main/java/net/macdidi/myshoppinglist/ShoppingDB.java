package net.macdidi.myshoppinglist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class ShoppingDB {
    private static final String DATABASE_NAME = "shopping.db";
    private static final String TABLE_SHOPPING_NAME = "shopping";
    private static final String TABLE_AUTO_NAME = "namelist";

    private static final int VERSION = 1;

    public static final String KEY_ID = "_id";
    public static final String NAME_COLUMN = "name";
    public static final String AMOUNT_COLUMN = "amount";
    public static final String DATE_COLUMN = "date";
    public static final String SELECTED_COLUMN = "selected";

    public static final String[] SHOPPING_COLUMNS = 
        {KEY_ID, NAME_COLUMN, AMOUNT_COLUMN, DATE_COLUMN, SELECTED_COLUMN};

    public static final String[] AUTO_COLUMNS = 
        {KEY_ID, NAME_COLUMN, SELECTED_COLUMN};

    private static final String CREATE_SHOPPING_TABLE =
        "CREATE TABLE " + TABLE_SHOPPING_NAME + " (" +
        KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        NAME_COLUMN + " TEXT NOT NULL, " +
        AMOUNT_COLUMN + " INTEGER NOT NULL, " +
        DATE_COLUMN + " LONG NOT NULL, " + 
        SELECTED_COLUMN + " INTEGER NOT NULL);";

    private static final String CREATE_AUTO_TABLE =
        "CREATE TABLE " + TABLE_AUTO_NAME + " (" +
        KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        NAME_COLUMN + " TEXT NOT NULL, " + 
        SELECTED_COLUMN + " INTEGER NOT NULL);";
    
    private SQLiteDatabase db;
    private MyHelper myHelper;
    
    private static ShoppingDB myShoppingDB = null;
    
    private ShoppingDB(Context context) {
        myHelper = new MyHelper(context, DATABASE_NAME, null, VERSION);
        db = myHelper.getWritableDatabase();
    }

    public static ShoppingDB getShoppingDB(Context context) {
        if (myShoppingDB == null) {
            myShoppingDB = new ShoppingDB(context);
        }

        if (!myShoppingDB.db.isOpen()) {
            myShoppingDB.db = myShoppingDB.myHelper.getWritableDatabase();
        }
        
        return myShoppingDB;
    }

    public void close() {
        db.close();
    }

    public long insert(String name, int amount) {
        long id = isNameExists(name);
        
        if (id > 0) {
            update(id, name, amount);
            return id;
        }
        else {
            ContentValues cv = new ContentValues();
            
            cv.put(NAME_COLUMN, name);
            cv.put(AMOUNT_COLUMN, amount);
            cv.put(DATE_COLUMN, System.currentTimeMillis());
            cv.put(SELECTED_COLUMN, 0);
            
            return db.insert(TABLE_SHOPPING_NAME, null, cv);
        }
    }

    private long isNameExists(String name) {
        long result = 0;
        String where = NAME_COLUMN + "='" + name + "'";
        Cursor data = db.query(TABLE_SHOPPING_NAME, SHOPPING_COLUMNS, where, null, null, null, null);
        
        if (data.moveToFirst()) {
            result = data.getLong(0);
        }
        
        data.close();

        return result;
    }

    public boolean delete(long id){
        String where = KEY_ID + "=" + id;
        return db.delete(TABLE_SHOPPING_NAME, where , null) > 0;
    }

    public boolean deleteSelected(){
        String where = SELECTED_COLUMN + "=1";
        return db.delete(TABLE_SHOPPING_NAME, where , null) > 0;
    }

    public boolean update(long id, String name, int amount) {
        ContentValues cv = new ContentValues();
        
        cv.put(NAME_COLUMN, name);
        cv.put(AMOUNT_COLUMN, amount);
        cv.put(DATE_COLUMN, System.currentTimeMillis());
        
        String where = KEY_ID + "=" + id;        
        return db.update(TABLE_SHOPPING_NAME, cv, where, null) > 0;         
    }

    public boolean updateSelected(long id, boolean selected) {
        ContentValues cv = new ContentValues();
        cv.put(SELECTED_COLUMN, selected ? 1 : 0);
        String where = KEY_ID + "=" + id;
        return db.update(TABLE_SHOPPING_NAME, cv, where, null) > 0;         
    }    

    public boolean updateAllSelected() {
        ContentValues cv = new ContentValues();
        cv.put(SELECTED_COLUMN, 1);
        return db.update(TABLE_SHOPPING_NAME, cv, null, null) > 0;         
    }

    public boolean updateAllUnselected() {
        ContentValues cv = new ContentValues();
        cv.put(SELECTED_COLUMN, 0);
        return db.update(TABLE_SHOPPING_NAME, cv, null, null) > 0;         
    }

    public List<ShoppingItem> getAllShoppingItem() {
        List<ShoppingItem> items = new ArrayList<ShoppingItem>();
        Cursor result = db.query(TABLE_SHOPPING_NAME, SHOPPING_COLUMNS, null, null, null, null, null);
        
        if (result.moveToFirst()) {
            do {
                ShoppingItem item = getRecord(result);
                items.add(item);
            } while (result.moveToNext());
        }
        
        result.close();
        
        return items;
    }

    public ShoppingItem getShoppingItem(long id) {
        ShoppingItem item = null;
        String where = KEY_ID + "=" + id;
        Cursor result = db.query(
            true, TABLE_SHOPPING_NAME, SHOPPING_COLUMNS, where, null, null, null, null, null);
        
        if (result.moveToFirst()) {
            item = getRecord(result);
        }
        
        result.close();
        
        return item;
    }    

    private ShoppingItem getRecord(Cursor cursor) {
        ShoppingItem result = new ShoppingItem();
        
        result.setId(cursor.getLong(0));
        result.setName(cursor.getString(1));
        result.setAmount(cursor.getInt(2));
        result.setDate(cursor.getLong(3));
        result.setSelected(cursor.getInt(4) == 1);
        
        return result;
    }

    public long insertName(String name) {
        ContentValues cv = new ContentValues();        
        cv.put(NAME_COLUMN, name);
        cv.put(SELECTED_COLUMN, 0);
        return db.insert(TABLE_AUTO_NAME, null, cv); 
    }

    public boolean deleteName(long id){
        String where = KEY_ID + "=" + id;
        return db.delete(TABLE_AUTO_NAME, where, null) > 0;
    }

    public boolean deleteName(){
        return db.delete(TABLE_AUTO_NAME, null, null) > 0;
    }

    public boolean deleteNameSelected(){
        String where = SELECTED_COLUMN + "=1";
        return db.delete(TABLE_AUTO_NAME, where , null) > 0;
    }

    public boolean updateNameSelected(long id, boolean selected) {
        ContentValues cv = new ContentValues();
        cv.put(SELECTED_COLUMN, selected ? 1 : 0);
        String where = KEY_ID + "=" + id;
        return db.update(TABLE_AUTO_NAME, cv, where, null) > 0;         
    }   

    public boolean updateAllNameSelected() {
        ContentValues cv = new ContentValues();
        cv.put(SELECTED_COLUMN, 1);
        return db.update(TABLE_AUTO_NAME, cv, null, null) > 0;         
    }

    public boolean updateAllNameUnselected() {
        ContentValues cv = new ContentValues();
        cv.put(SELECTED_COLUMN, 0);
        return db.update(TABLE_AUTO_NAME, cv, null, null) > 0;         
    }    

    public List<NameItem> getAllNameItem() {
        List<NameItem> items = new ArrayList<NameItem>();
        Cursor result = db.query(TABLE_AUTO_NAME, AUTO_COLUMNS, null, null, null, null, null);
        
        if (result.moveToFirst()) {
            do {
                NameItem item = new NameItem();
                
                item.setId(result.getLong(0));
                item.setName(result.getString(1));
                item.setSelected(result.getInt(2) == 1);
                
                items.add(item);
            } while (result.moveToNext());
        }
        
        result.close();
        
        return items;
    }

    public String[] getAllNames() {
        String[] result = {};
        List<String> items = new ArrayList<String>();
        Cursor data = db.query(TABLE_AUTO_NAME, AUTO_COLUMNS, null, null, null, null, null);
        
        if (data.moveToFirst()) {
            do {
                items.add(data.getString(1));
            } while (data.moveToNext());
            
            int size = items.size();
            
            if (size > 0) {
                result = new String[size];
                
                for (int i = 0; i < size; i++) {
                    result[i] = items.get(i);
                }
            }
        }
        
        data.close();
        
        return result;
    }

    public boolean isAutoExists(String name) {
        String where = NAME_COLUMN + "='" + name + "'";
        Cursor data = db.query(TABLE_AUTO_NAME, AUTO_COLUMNS, where, null, null, null, null);
        boolean result = data.moveToFirst();
        data.close();
        return result;
    }

    private static class MyHelper extends SQLiteOpenHelper {
        public MyHelper(Context context, String name, CursorFactory factory, int version){
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_SHOPPING_TABLE);
            db.execSQL(CREATE_AUTO_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_SHOPPING_NAME);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_AUTO_NAME);
            onCreate(db);
        }
    }
    
}
