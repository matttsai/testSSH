package net.macdidi.myshoppinglist;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ShoppingDataActivity extends AppCompatActivity {
    
    private AutoCompleteTextView name;
    private EditText amount;
    private Button submit;
    private Button back;
    
    private int added = 0;
    private Intent intent;
    private String action;
    
    private ShoppingDB myDb;
    
    private ArrayAdapter<String> autoAdapter;
    
    private static final String ACTION_ADD = "net.macdidi.action.ADD_SHOPPING_DATA";
    private static final String ACTION_EDIT = "net.macdidi.action.EDIT_SHOPPING_DATA";
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shopping_data);
        
        myDb = ShoppingDB.getShoppingDB(getApplicationContext());
        intent = getIntent();
        action = intent.getAction();
        
        processViews();
        processControllers();
    }

    private void processViews() {
        name = (AutoCompleteTextView) findViewById(R.id.name);
        amount = (EditText) findViewById(R.id.amount);
        submit = (Button) findViewById(R.id.submit);
        back = (Button) findViewById(R.id.back);
        
        String[] auto = myDb.getAllNames();
        autoAdapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, auto);
        
        
        if (action.equals(ACTION_ADD)) {
            submit.setText(R.string.add);
        }
        else if (action.equals(ACTION_EDIT)) {
            submit.setText(R.string.edit);
            long id = intent.getLongExtra("id", 0);
            ShoppingItem item = myDb.getShoppingItem(id);
            
            if (item != null) {
                name.setText(item.getName());
                amount.setText(Integer.toString(item.getAmount()));
            }
        }
        
        name.setAdapter(autoAdapter);
    }
    
    private void processControllers() {
        ButtonListener listener = new ButtonListener();
        submit.setOnClickListener(listener);
        back.setOnClickListener(listener);
    }
    
    private class ButtonListener implements OnClickListener {

        @Override
        public void onClick(View view) {
            if (view == submit) {
                processSubmit();
            }
            else if (view == back) {
                finish();
            }
        }
        
    }
    
    private void clearField() {
        name.setText("");
        amount.setText("");
        name.requestFocus();
    }
    
    private void processSubmit() {
        if (!checkValue()) {
            return;
        }        
        
        final String nameValue = name.getText().toString();
        final int amountValue = Integer.parseInt(amount.getText().toString());
        
        if (action.equals(ACTION_ADD)) {
            myDb.insert(nameValue, amountValue);
            
            added++;
            String addText = getString(R.string.add) + " (" + added + ")"; 
            submit.setText(addText);
            Toast.makeText(ShoppingDataActivity.this, getString(R.string.add_message), Toast.LENGTH_SHORT).show();
            clearField();
        }
        else if (action.equals(ACTION_EDIT)) {
            long id = intent.getLongExtra("id", 0);
            myDb.update(id, nameValue, amountValue);
            Toast.makeText(ShoppingDataActivity.this, getString(R.string.edit_message), Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK, intent);
            finish();
        }
        
        if (!myDb.isAutoExists(nameValue)){
            myDb.insertName(nameValue);
            autoAdapter.add(nameValue);
            autoAdapter.notifyDataSetChanged();
        }        
    }
    
    private boolean checkValue() {
        boolean result = true;
        StringBuffer message = new StringBuffer("");
        
        String nameValue = name.getText().toString();
        String amountValue = amount.getText().toString();
        
        if (nameValue.trim().length() == 0) {
            message.append(getString(R.string.name_require) + "\n");
        }
        
        if (amountValue.trim().length() == 0) {
            message.append(getString(R.string.amount_require) + "\n");
        }
        else {
            try {
                Integer.parseInt(amountValue);
            }
            catch (NumberFormatException e){
                message.append(getString(R.string.number_require) + "\n");
            }
        }
        
        if (message.length() > 0) {
            AlertDialog.Builder adb = new AlertDialog.Builder(this);
            adb.setTitle(getString(R.string.data_error));
            adb.setMessage(message.toString());        
            adb.setPositiveButton(getString(R.string.ok), null);        
            adb.show();
            result = false;
        }
        
        return result;
    }    
}
