package net.macdidi.myshoppinglist;

import java.util.Date;
import java.util.Locale;

public class ShoppingItem {

    private long id;
    private String name;
    private int amount;
    private long date;
    private boolean selected;
    
    public ShoppingItem() {
        
    }
    

    public ShoppingItem(long id, String name, int amount, long date, boolean selected) {
        this.id = id;
        this.name = name;
        this.amount = amount;
        this.date = date;
        this.selected = selected;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }
    
    public int getSelected() {
        return (selected ? 1 : 0);
    }
    
    public boolean isSelected() {
        return selected;
    }
    
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
    public String getLocaleDate() {
        return String.format(Locale.getDefault(), "%tF", new Date(date));
    }
    
    public String toString() {
        return String.format("%s (%d)", name, amount);
    }
    
}
