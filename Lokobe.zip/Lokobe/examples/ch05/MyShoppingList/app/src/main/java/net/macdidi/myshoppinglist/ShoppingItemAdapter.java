package net.macdidi.myshoppinglist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class ShoppingItemAdapter extends ArrayAdapter<ShoppingItem> {

    private int resource;
    private List<ShoppingItem> items;

    public ShoppingItemAdapter(Context context, int resource,
            List<ShoppingItem> items) {
        super(context, resource, items);
        this.resource = resource;
        this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout shoppingItemView;

        final ShoppingItem item = getItem(position);

        String id = Long.toString(item.getId());
        String name = item.getName();
        String amount = Integer.toString(item.getAmount());
        boolean selected = item.isSelected();

        if (convertView == null) {
            shoppingItemView = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater vi = (LayoutInflater) getContext().getSystemService(
                    inflater);
            vi.inflate(resource, shoppingItemView, true);
        }
        else {
            shoppingItemView = (LinearLayout) convertView;
        }

        TextView idView = (TextView) shoppingItemView.findViewById(R.id.id);
        TextView nameView = (TextView) shoppingItemView.findViewById(R.id.name);
        TextView amountView = (TextView) shoppingItemView.findViewById(R.id.amount);
        CheckBox selectedView = (CheckBox) shoppingItemView.findViewById(R.id.selected);

        idView.setText(id);
        nameView.setText(name);
        amountView.setText(amount);
        
        if (selectedView != null) {
            selectedView.setChecked(selected);
        }

        return shoppingItemView;
    }
    
    public void set(int index, ShoppingItem item) {
        if (index >= 0 && index < items.size()) {
            items.set(index, item);
            notifyDataSetChanged();
        }
    }

}
