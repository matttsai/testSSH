package net.macdidi.myshoppinglist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

public class ShoppingMaintainActivity extends AppCompatActivity {
    
    private ListView items;
    private ShoppingItemAdapter sia;
    
    private ShoppingDB myDb;
    
    private static final int DO_EDIT = 0;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shopping_maintain);
        
        myDb = ShoppingDB.getShoppingDB(getApplicationContext());
        
        processViews();
        
        registerForContextMenu(items);        
        
        List<ShoppingItem> all = myDb.getAllShoppingItem();
        sia = new ShoppingItemAdapter(this, R.layout.shoppinglist_view, all);
        items.setAdapter(sia);
    }
    
    @Override
    public void onCreateContextMenu(ContextMenu menu, View view,
            ContextMenuInfo menuInfo) {
        
        if (view == items) {
            AdapterView.AdapterContextMenuInfo info = 
                (AdapterView.AdapterContextMenuInfo)menuInfo;
            ShoppingItem item = sia.getItem(info.position);
            menu.setHeaderTitle(item.getName());
            
            String[] menuItems = getResources().getStringArray(R.array.action_array);
            
            for (int i = 0; i < menuItems.length; i++) {
                menu.add(Menu.NONE, i, i, menuItems[i]);
            }
        }
    }
    
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = 
            (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        final ShoppingItem target = sia.getItem(info.position);
        int menuItemIndex = item.getItemId();
        
        if (menuItemIndex == 0) {
            Intent intent = new Intent("net.macdidi.action.EDIT_SHOPPING_DATA");
            intent.putExtra("id", target.getId());
            intent.putExtra("position", sia.getPosition(target));
            startActivityForResult(intent, DO_EDIT);
        }
        else if (menuItemIndex == 1) {
            AlertDialog.Builder adb = new AlertDialog.Builder(this);
            adb.setTitle(getString(R.string.delete));
            adb.setMessage(target.getName() + "\n\n" + getString(R.string.confirm_delete));
            adb.setIcon(R.drawable.warning);
            
            adb.setPositiveButton(getString(R.string.delete), 
                new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        myDb.delete(target.getId());
                        sia.remove(target);
                        sia.notifyDataSetChanged();
                    }
                });
            adb.setNegativeButton(getString(R.string.back), null);
            
            adb.show();
        }
        
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == DO_EDIT && resultCode == RESULT_OK) {
            long id = data.getLongExtra("id", 0);
            int position = data.getIntExtra("position", 0);
            ShoppingItem item = myDb.getShoppingItem(id);
            sia.set(position, item);
        }
    }

    private void processViews() {
        items = (ListView) findViewById(R.id.items);
    }
    
}
