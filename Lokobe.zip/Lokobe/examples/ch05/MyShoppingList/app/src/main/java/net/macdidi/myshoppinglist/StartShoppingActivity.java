package net.macdidi.myshoppinglist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class StartShoppingActivity extends AppCompatActivity {
    
    private ListView start_items;
    private Button start_delete;
    private Button start_deselect_all;
    private Button start_select_all;

    private ShoppingItemAdapter sia;
    private ShoppingDB myDb;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_shopping);
        
        myDb = ShoppingDB.getShoppingDB(getApplicationContext());
        
        processViews();
        processControllers();
        processModel();
        
        configFooter();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        saveStatus();
    }
    
    private void processViews() {
        start_items = (ListView) findViewById(R.id.start_items);
        start_delete = (Button) findViewById(R.id.start_delete);
        start_deselect_all = (Button) findViewById(R.id.start_deselect_all);
        start_select_all = (Button) findViewById(R.id.start_select_all);
    }
    
    private void processControllers() {
        ButtonListener listener = new ButtonListener();
        
        start_delete.setOnClickListener(listener);
        start_deselect_all.setOnClickListener(listener);
        start_select_all.setOnClickListener(listener);
        
        start_items.setOnItemClickListener(new CheckedListener());
    }
    
    private class ButtonListener implements OnClickListener {

        @Override
        public void onClick(View view) {
            if (view == start_delete) {
                int selectedCount = getSelectedCount();
                
                if (selectedCount > 0) {
                    saveStatus();
                    
                    AlertDialog.Builder adb = new AlertDialog.Builder(StartShoppingActivity.this);
                    adb.setTitle(getString(R.string.delete_selected));
                    adb.setIcon(R.drawable.warning);
                    adb.setMessage(getString(R.string.confirm_delete_selected) + "\n\n" +
                            selectedCount + " " + getString(R.string.item));                    
                    
                    adb.setPositiveButton(getString(R.string.delete), 
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                myDb.deleteSelected();
                                processModel();
                                configFooter();
                            }
                        });
                    adb.setNegativeButton(getString(R.string.back), null);
                    
                    adb.show();
                }
            }
            else if (view == start_deselect_all) {
                for (int i = 0; i < sia.getCount(); i++) {
                    sia.getItem(i).setSelected(false);
                }
                
                myDb.updateAllUnselected();
                sia.notifyDataSetChanged();
                configFooter();
            }
            else if (view == start_select_all) {
                for (int i = 0; i < sia.getCount(); i++) {
                    sia.getItem(i).setSelected(true);
                }
                
                myDb.updateAllSelected();
                sia.notifyDataSetChanged();
                configFooter();
            }
        }
        
    }
    
    private class CheckedListener implements OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                long id) {            
            ShoppingItem target = sia.getItem(position);
            target.setSelected(!target.isSelected());
            sia.set(position, target);
            configFooter();
        }
        
    }
    
    private void processModel() {
        List<ShoppingItem> all = myDb.getAllShoppingItem();
        sia = new ShoppingItemAdapter(this, R.layout.start_shopping_view, all);
        start_items.setAdapter(sia);        
    }    
    
    private void saveStatus() {
        for (int i = 0; i < sia.getCount(); i++) {
            ShoppingItem item = sia.getItem(i);
            myDb.updateSelected(item.getId(), item.isSelected());
        }        
    }
    
    private int getSelectedCount() {
        int result = 0;
        
        for (int i = 0; i < sia.getCount(); i++) {
            if (sia.getItem(i).isSelected()) {
                result++;
            }
        }
        
        return result;
    }
    
    private void configFooter() {
        int selectedCount = getSelectedCount();
        
        if (selectedCount > 0) {
            start_delete.setEnabled(true);
            start_delete.setText(getString(R.string.delete) + " (" + selectedCount + ")");
        }
        else {
            start_delete.setEnabled(false);
            start_delete.setText(getString(R.string.delete));
        }
    }

}
