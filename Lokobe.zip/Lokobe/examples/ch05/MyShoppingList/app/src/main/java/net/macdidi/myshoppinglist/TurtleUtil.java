package net.macdidi.myshoppinglist;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class TurtleUtil {
    private static SharedPreferences sp = null;

    public static boolean isFirstTime(Context context){
        return getSharedPreferences(context).getBoolean("FIRST_TIME", true);
    }

    public static void setFirstTime(Context context) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean("FIRST_TIME", false);
        editor.commit();
    }

    public static boolean isShowDoc(Context context){
        return getSharedPreferences(context).getBoolean("SHOWDOC_PREF", true);
    }

    public static void setShowDoc(Context context, boolean show){
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean("SHOWDOC_PREF", show);
        editor.commit();
    }    
    
    private static SharedPreferences getSharedPreferences(Context context) {
        if (sp == null) {
            return PreferenceManager.getDefaultSharedPreferences(context);
        }
        else {
            return sp;
        }
    }
    
}
