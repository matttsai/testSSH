package net.macdidi.layout01;

public class Calculator {

    private static final char NO_OP = '\0';
    private static final char PLUS = '+';
    private static final char SUBTRACT = '-';
    private static final char MULTIPLY = '*';
    private static final char DIVIDE = '/';

    private double number1 = 0.0;
    private char operator = NO_OP;

    public String opEquals(String number) {
        double result = performOperation(parseNumber(number));
        operator = NO_OP;
        return removeDotZero((number1 = result));
    }

    public String opAdd(String number) {
        double result = performOperation(parseNumber(number));
        operator = PLUS;
        return removeDotZero((number1 = result));
    }

    public String opSubtract(String number) {
        double result = performOperation(parseNumber(number));
        operator = SUBTRACT;
        return removeDotZero((number1 = result));
    }

    public String opMultiply(String number) {
        double result = performOperation(parseNumber(number));
        operator = MULTIPLY;
        return removeDotZero((number1 = result));
    }

    public String opDivide(String number) {
        double result = performOperation(parseNumber(number));
        operator = DIVIDE;
        return removeDotZero((number1 = result));
    }

    public void clear() {
        number1 = 0;
    }

    private double performOperation(double number2) {
        double result = 0.0F;

        switch (operator) {
            case NO_OP:
                result = number2;
                break;
            case PLUS:
                result = number1 + number2;
                break;
            case SUBTRACT:
                result = number1 - number2;
                break;
            case MULTIPLY:
                result = number1 * number2;
                break;
            case DIVIDE:
                result = number1 / number2;
                break;
        }

        return result;
    }

    private String removeDotZero(double number) {
        String result = Double.toString(number);
        int length = result.length();

        if (result.length() > 2 && result.substring(length - 2).equals(".0")) {
            result = result.substring(0, length - 2);
        }

        return result;
    }

    private double parseNumber(String number) {
        int length = number.length();
        double real_number;

        if (length == 0) {
            return 0;
        }

        if (number.substring(length - 1).equals(".")) {
            number = number.substring(0, length - 1);
        }

        try {
            real_number = Double.parseDouble(number);
        } catch (NumberFormatException e) {
            real_number = Double.NaN;
        }

        return real_number;
    }

}
