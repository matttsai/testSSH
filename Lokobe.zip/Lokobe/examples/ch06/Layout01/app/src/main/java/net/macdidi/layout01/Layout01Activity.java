package net.macdidi.layout01;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Layout01Activity extends AppCompatActivity {

    private Button cplus, cminus, cmul, cdiv, cpoint, cequal;
    private Button c0, c1, c2, c3, c4, c5, c6, c7, c8, c9;
    private Button clear;
    private Button back;
    private TextView result;
    private TextView operation;
    private Calculator calculator;
    private boolean isReady;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout01);

        calculator = new Calculator();

        processViews();
        processControllers();
    }

    private void processViews() {
        cplus = (Button) findViewById(R.id.cplus);
        cminus = (Button) findViewById(R.id.cminus);
        cmul = (Button) findViewById(R.id.cmul);
        cdiv = (Button) findViewById(R.id.cdiv);
        cpoint = (Button) findViewById(R.id.cpoint);
        cequal = (Button) findViewById(R.id.cequal);

        c0 = (Button) findViewById(R.id.c0);
        c1 = (Button) findViewById(R.id.c1);
        c2 = (Button) findViewById(R.id.c2);
        c3 = (Button) findViewById(R.id.c3);
        c4 = (Button) findViewById(R.id.c4);
        c5 = (Button) findViewById(R.id.c5);
        c6 = (Button) findViewById(R.id.c6);
        c7 = (Button) findViewById(R.id.c7);
        c8 = (Button) findViewById(R.id.c8);
        c9 = (Button) findViewById(R.id.c9);

        clear = (Button) findViewById(R.id.clear);
        back = (Button) findViewById(R.id.back);

        result = (TextView) findViewById(R.id.result);
        operation = (TextView) findViewById(R.id.operation);
    }

    private void processControllers() {
        OnClickListener op = new OperationListener();
        cplus.setOnClickListener(op);
        cminus.setOnClickListener(op);
        cmul.setOnClickListener(op);
        cdiv.setOnClickListener(op);
        cequal.setOnClickListener(op);

        OnClickListener nop = new NonOperationListener();
        c0.setOnClickListener(nop);
        c1.setOnClickListener(nop);
        c2.setOnClickListener(nop);
        c3.setOnClickListener(nop);
        c4.setOnClickListener(nop);
        c5.setOnClickListener(nop);
        c6.setOnClickListener(nop);
        c7.setOnClickListener(nop);
        c8.setOnClickListener(nop);
        c9.setOnClickListener(nop);
        cpoint.setOnClickListener(nop);

        clear.setOnClickListener(new ClearListener());
        back.setOnClickListener(new BackListener());
    }

    private class OperationListener implements OnClickListener {
        public void onClick(View view) {
            String value = result.getText().toString();
            result.setText("");
            String cal = "";

            if (view == cplus) {
                cal = calculator.opAdd(value);
            } else if (view == cminus) {
                cal = calculator.opSubtract(value);
            } else if (view == cmul) {
                cal = calculator.opMultiply(value);
            } else if (view == cdiv) {
                cal = calculator.opDivide(value);
            } else if (view == cequal) {
                cal = calculator.opEquals(value);
            }

            operation.setText(((Button) view).getText());
            result.setText(cal);
            isReady = true;
        }
    }

    private class NonOperationListener implements OnClickListener {
        public void onClick(View view) {
            if (isReady) {
                result.setText(((Button) view).getText());
                isReady = false;
            } else {
                String value = result.getText().toString();

                if (view == cpoint) {
                    if (value.contains(".")) {
                        return;
                    } else if (value.length() == 0) {
                        value = "0";
                    }
                }

                result.setText(value + ((Button) view).getText());
            }
        }
    }

    private class ClearListener implements OnClickListener {
        public void onClick(View view) {
            result.setText("");
            calculator.clear();
        }
    }

    private class BackListener implements OnClickListener {
        public void onClick(View view) {
            String value = result.getText().toString();

            if (value.length() > 0) {
                result.setText(value.substring(0, value.length() - 1));
            }
        }
    }

}
